package com.sanbait.shadowgrid.mixin;

// This file is obsolete and kept only because deletion failed.
// It is no longer a Mixin and does nothing.
public class MixinNoiseBasedBiomeSource {
}
